#pragma once
class album
{
private:
	int aId;
	int arCustomerId;

public:
	album();
	album(int ID, int CID);
	void assingn_alDetails();
	void display_alDetails();
};


