#include "album.h"
#include <cstring>
album::album()
{
}
album::album(int ID, int CID)
{
	aId = ID;
	arCustomerId = CID;
}
void album::assingn_alDetails()
{
}

void album::display_alDetails()
{
}
