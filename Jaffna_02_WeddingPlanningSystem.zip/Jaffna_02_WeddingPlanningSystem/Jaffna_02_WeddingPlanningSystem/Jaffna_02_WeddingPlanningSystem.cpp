#include <iostream>
#include"album.h"
using namespace std;
int main()
{

    album Al1;
    Al1.display_alDetails();

    return 0;
};